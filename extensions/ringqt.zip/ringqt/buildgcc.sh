qmake ring_qt.pro
make
cp libringqt.so ../../lib

