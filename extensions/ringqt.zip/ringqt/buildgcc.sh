qmake ring_qt515.pro
make
cp libringqt.so ../../lib

