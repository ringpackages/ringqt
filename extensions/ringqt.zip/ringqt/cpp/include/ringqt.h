/* Copyright (c) 2019 Mahmoud Fayed <msfclipper@yahoo.com> */

#ifndef RINGQT_H
#define RINGQT_H

#define RINGQT_EVENT_SIZE 200

#endif 