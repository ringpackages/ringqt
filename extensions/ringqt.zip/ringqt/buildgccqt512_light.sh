qmake ring_qt512_light.pro
make
cp libringqt_light.so ../../lib

