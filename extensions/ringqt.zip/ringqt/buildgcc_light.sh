qmake ring_qt515_light.pro
make
cp libringqt_light.so ../../lib

