qmake-qt5 ring_qt.pro
make
cp libringqt.so ../../lib

