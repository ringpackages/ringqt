qmake ring_qt515_core.pro
make
cp libringqt_core.so ../../lib

