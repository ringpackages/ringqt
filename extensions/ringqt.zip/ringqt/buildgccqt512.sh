qmake ring_qt512.pro
make
cp libringqt.so ../../lib

