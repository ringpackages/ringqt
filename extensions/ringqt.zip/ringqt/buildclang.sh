/usr/local/bin/qmake ring_qt595.pro -r -spec macx-clang
make
cp *.dylib ../../lib
