Ring programming language - BinUpdate folder
============================================

In this folder 

(1) installqt515.bat - Copy Qt 5.15.0 DLL files to the bin folder

(2) installqt512.bat - Copy Qt 5.12.6 DLL files to the bin folder

(3) removedebugdlls.ring - Clean ring/bin folder (Remove debug files)
